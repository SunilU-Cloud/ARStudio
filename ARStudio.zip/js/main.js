AOS.init({
	duration: 800,
	easing: 'slide',
	once: false
});

